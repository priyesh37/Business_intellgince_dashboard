package com.project.utils;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import com.project.model.PatternVO;

@Component
public class BaseMethods {

	public static Map<String, Object> crawlData(String trendName, String link, int pageno) {

		List<String> patternList = new ArrayList();
		List<PatternVO> patterndatalist = new ArrayList();

		System.out.println(pageno);
		int pagecount = 41, index = 1;
		String topicName = trendName.toLowerCase();
		String s1link = link.replace("s1=TREND_NAME", "s1=" + topicName + "");
		String OSlink = s1link.replace("OS=TREND_NAME", "OS=" + topicName + "");
		String RSlink = OSlink.replace("RS=TREND_NAME", "RS=" + topicName + "");

		try {

			for (index = 2001; index <= pageno * 50; index++) {

				PatternVO addpattern = new PatternVO();
				if (index % 50 == 1) {
					pagecount = pagecount + 1;
				}
				String pagecountlink = RSlink.replace("p=1", "p=" + pagecount + "");
				String newlink = pagecountlink.replace("r=1", "r=" + index + "");
				System.out.println(index);
				//System.out.println(newlink);
				patternList.add(newlink);

				// System.out.println(j+" "+i);

				Document page = Jsoup.connect(newlink).timeout(0).get();

				Element table1 = page.select("table").get(2); // select the
																// first table.
				Elements col1 = table1.select("td");
				Elements rows1 = table1.select("tr");

				Elements cols1 = rows1.select("td");
				Elements th1 = rows1.select("th");
				Elements b1 = rows1.select("b");

				String unitedstatepatentNo = cols1.get(1).text();
				addpattern.setUnitedstatepatentNo(unitedstatepatentNo);

				String date = cols1.get(3).text();
				addpattern.setDate(date);

				Elements title = page.select("body > font");

				String patterntitle = title.text();
				addpattern.setTitle(patterntitle);

				Element table = page.select("table").get(3); // select the first
																// table.
				Elements col = table.select("td");
				Elements rows = table.select("tr");
//System.out.println(col.size());
				for (int k = 0; k < col.size(); k++) { // first row is the col
														// names so skip it.

					Elements cols = rows.select("td");
					Elements th = rows.select("th");
					Elements b = rows.select("b");
					if (k == 1) {
						// System.out.println(th.get(k).text()+" ");
						// pattern.println(th.get(k).text() + " ");

					}

					else {
						// System.out.println(th.get(k).text()+"
						// "+cols.get(k).text());

						String s1 = th.get(k).text();
						if(s1.equals(" "))
						{
							
						}
						if (s1.equals("Inventors:")) {
							String inventors = cols.get(k).text();

							addpattern.setInventors(inventors);
						} else if (s1.equals("Name")) {
							String name = cols.get(k).text();

							addpattern.setApplicantname(name);
						} else if (s1.equals("City")) {
							String city = cols.get(k).text();

							addpattern.setApplicantcity(city);
						} else if (s1.equals("State")) {
							String state = cols.get(k).text();

							addpattern.setApplicantstate(state);
						} else if (s1.equals("Country")) {
							String country = cols.get(k).text();

							addpattern.setApplicantcountry(country);
						} else if (s1.equals("Assignee:")) {
							String assignee = cols.get(k).text();

							addpattern.setAssignee(assignee);
						} else if (s1.equals("Family ID:")) {
							String familyid = cols.get(k).text();

							addpattern.setFamilyid(familyid);
						} else if (s1.equals("Appl. No.:")) {
							String applicationno = cols.get(k).text();

							addpattern.setApplicationno(applicationno);
						} else if (s1.equals("Filed:")) {
							String filed = cols.get(k).text();

							addpattern.setFileddate(filed);
						} else if (s1.equals("PCT Filed:")) {
							String pctfiled = cols.get(k).text();

							addpattern.setPctfileddate(pctfiled);
						} else if (s1.equals("PCT No.:")) {
							String pctno = cols.get(k).text();

							addpattern.setPctno(pctno);
						} else if (s1.equals("PCT Pub. No.:")) {
							String pctpubno = cols.get(k).text();

							addpattern.setPctpublicationNo(pctpubno);
						} else if (s1.equals("PCT Pub. Date:")) {
							String pctpubdate = cols.get(k).text();

							addpattern.setPctpublicationDate(pctpubdate);
						}
					}
				}

				Elements abs1 = page.select("body > p:nth-child(11)");

				String patternabstract = abs1.text();
				System.out.println(patternabstract);

				addpattern.setPattentAbstract(patternabstract);

				patterndatalist.add(addpattern);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		Map map = new HashMap();

		map.put("patterndatalist", patterndatalist);
		map.put("patternList", patternList);

		return map;

	}
	
	public static List<String>  Ngrams(int number,String str)
	{
		ArrayList<String> ngms=new ArrayList<String>();
		String s1[]=str.split("[\\s.,]+");
				for(int i=0;i<s1.length-number+1;i++)
				{
					ngms.add(concat1(s1, i,i+number));
					
				}
		
		return ngms;
		
	}
	 public static String concat1(String[] words, int start, int end) {
	        StringBuilder sb = new StringBuilder();
	        for (int i = start; i < end; i++)
	        {
	        	
	            sb.append(words[i]);
	           
	        }
	        return sb.toString();
	    }
	
	
	
}
