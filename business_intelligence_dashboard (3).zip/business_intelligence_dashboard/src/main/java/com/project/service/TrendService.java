package com.project.service;
import java.util.List;

import com.project.model.TrendVO;
public interface TrendService {
	
	void saveTrend(TrendVO trendVO) ;
	List<TrendVO> getTrend();
	List<TrendVO> getTrendById(TrendVO trendVO);

}
