package com.project.service;

import java.util.List;

import com.project.model.CrawlPatternVO;
import com.project.model.FinalAbstractVO;
import com.project.model.KeywordVO;
import com.project.model.PatternVO;
import com.project.model.TrendVO;

public interface CrawlDataService {
	public void getCrawlData(String TrendName, String link, int pageno,TrendVO trendVO);
	List<CrawlPatternVO> getCrawlPatternByTopic(TrendVO trendVO);
	List<PatternVO> getPatternDetailsByTopic(TrendVO trendVO);
	List<PatternVO> getPatternDetails(PatternVO patternVO);
	public void getAbstarctByTopic(TrendVO trendVO);
	public void getfinalabstract(TrendVO trendVO);

	List getCount(TrendVO trendVO);
	List getCountFromYear(KeywordVO keywordVO);

}
