package com.project.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.KeywordDAO;
import com.project.model.KeywordVO;
import com.project.model.StopwordVO;
import com.project.model.TrendVO;

@Service
public class KeywordServiceImpl implements KeywordService {

	@Autowired
	KeywordDAO keywordDAO;

	@Transactional
	public void saveKeyword(KeywordVO keywordVO) {
		this.keywordDAO.saveKeyword(keywordVO);

	}

	//
	@Transactional
	public List<KeywordVO> getKeywordByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		return this.keywordDAO.getKeywordByTopic(trendVO);
	}

	@Transactional
	public List<KeywordVO> getKeyword() {
		// TODO Auto-generated method stub
		return this.keywordDAO.getKeyword();
	}

	@Transactional
	public List<KeywordVO> getKeywordById(KeywordVO keywordVO) {
		return this.keywordDAO.getKeywordById(keywordVO);
	}

	@Transactional
	public void updateKeyword(KeywordVO keywordVO) {
		this.keywordDAO.updateKeyword(keywordVO);

	}

}
