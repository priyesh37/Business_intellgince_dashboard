package com.project.service;

import java.util.List;

import com.project.model.StopwordVO;

public interface StopwordService {

	public void saveStopword(StopwordVO stopwordVO);
	List<StopwordVO> getStopword();
	List<StopwordVO> getStopwordById(StopwordVO stopwordVO);
	public void updateStopword(StopwordVO stopwordVO);

}
