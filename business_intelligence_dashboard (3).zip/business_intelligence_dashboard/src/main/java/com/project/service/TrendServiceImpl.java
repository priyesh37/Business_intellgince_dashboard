package com.project.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.TrendDAO;
import com.project.model.TrendVO;;

@Service
@Transactional
public class TrendServiceImpl implements TrendService {
	@Autowired
	private TrendDAO trendDAO;
	@Override
	public void saveTrend(TrendVO trendVO) {
		// TODO Auto-generated method stub
		this.trendDAO.saveTrend(trendVO);
	}
	@Override
	public List<TrendVO> getTrend() {
		// TODO Auto-generated method stub
		return this.trendDAO.getTrend();
	}
	@Override
	public List<TrendVO> getTrendById(TrendVO trendVO) {
		// TODO Auto-generated method stub
		return 	this.trendDAO.getTrendById(trendVO);
	}
	
	

}
