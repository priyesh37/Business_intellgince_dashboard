package com.project.service;

import java.util.List;

import com.project.model.KeywordVO;
import com.project.model.StopwordVO;
import com.project.model.TrendVO;


public interface KeywordService {
	public void saveKeyword(KeywordVO keywordVO);
	List<KeywordVO> getKeyword();
	List<KeywordVO> getKeywordByTopic(TrendVO trendVO);
	List<KeywordVO> getKeywordById(KeywordVO keywordVO);
	public void updateKeyword(KeywordVO keywordVO);
}
