package com.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "final_abstract_table")
public class FinalAbstractVO {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	@Column(name="final_abstract")
	private String finalabstract;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getFinalabstract() {
		return finalabstract;
	}
	public void setFinalabstract(String finalabstract) {
		this.finalabstract = finalabstract;
	}
	public PatternVO getPatternVO() {
		return patternVO;
	}
	public void setPatternVO(PatternVO patternVO) {
		this.patternVO = patternVO;
	}
	@ManyToOne
	@JoinColumn(name = "pattern_details_id")
	private PatternVO patternVO;
	@ManyToOne
	@JoinColumn(name = "trend_id")
	private TrendVO trendVO;
	public TrendVO getTrendVO() {
		return trendVO;
	}
	public void setTrendVO(TrendVO trendVO) {
		this.trendVO = trendVO;
	}

}
