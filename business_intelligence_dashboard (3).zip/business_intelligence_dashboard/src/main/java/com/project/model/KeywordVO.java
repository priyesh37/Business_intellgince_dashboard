package com.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "keyword_table")
public class KeywordVO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "dd")
	private int id;

	@Column(name = "keyword")
	private String keyword;

	@Column(name = "status")
	private boolean status;

	@ManyToOne
	@JoinColumn(name = "trend_id")
	private TrendVO trendVO;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public TrendVO getTrendVO() {
		return trendVO;
	}

	public void setTrendVO(TrendVO trendVO) {
		this.trendVO = trendVO;
	}

}
