package com.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "keyword_count_table")
public class KeywordCountVO {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public TrendVO getTrendVO() {
		return trendVO;
	}
	public void setTrendVO(TrendVO trendVO) {
		this.trendVO = trendVO;
	}
	public int getPatternyear() {
		return patternyear;
	}
	public void setPatternyear(int patternyear) {
		this.patternyear = patternyear;
	}
	@Column(name="keyword")
	private String keyword;
	@Column(name="year")
	private int patternyear;
	@Column(name="countkeyword")
	private int count;
	@ManyToOne
	@JoinColumn(name = "trend_id")
	private TrendVO trendVO;

}
