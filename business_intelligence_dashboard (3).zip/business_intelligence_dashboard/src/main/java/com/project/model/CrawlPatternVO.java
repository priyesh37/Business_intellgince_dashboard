package com.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "data_pattern_table")
public class CrawlPatternVO {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "Link")
	private String link;

	@ManyToOne
	@JoinColumn(name = "trend_id")
	private TrendVO trendVO;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public TrendVO getTrendVO() {
		return trendVO;
	}

	public void setTrendVO(TrendVO trendVO) {
		this.trendVO = trendVO;
	}

}
