package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.model.KeywordVO;
import com.project.model.TrendVO;
import com.project.service.KeywordService;
import com.project.service.TrendService;

@RestController
public class KeywordController {

	@Autowired
	private TrendService TrendService;

	@Autowired
	private KeywordService KeywordService;

	@GetMapping(value = "admin/addKeyword")
	public ModelAndView addKeyword() {
		List<TrendVO> trendList = this.TrendService.getTrend();
		return new ModelAndView("admin/addKeyword", "trendList", trendList).addObject("KeywordVO", new KeywordVO());
	}

	@PostMapping(value = "admin/saveKeyword")
	public ModelAndView saveKeyword(@RequestParam String[] keywords, @RequestParam int trendId) {

		TrendVO trendVO = new TrendVO();
		trendVO.setId(trendId);

		for (String string : keywords) {
			KeywordVO keywordVO = new KeywordVO();
			keywordVO.setStatus(true);
			keywordVO.setKeyword(string);
			keywordVO.setTrendVO(trendVO);
			this.KeywordService.saveKeyword(keywordVO);
		}
		return new ModelAndView("redirect:viewKeyword");
	}

	@GetMapping(value = "admin/viewKeyword")
	public ModelAndView viewKeyword() {
		List<TrendVO> trendList = this.TrendService.getTrend();
		return new ModelAndView("admin/viewKeyword", "trendList", trendList);
	}

	@GetMapping(value = "admin/findKeywordById")
	public ResponseEntity findKeywordById(@RequestParam int id, TrendVO trendVO,KeywordVO keywordVO) {
		trendVO.setId(id);
		List<KeywordVO> keywordList = this.KeywordService.getKeywordByTopic(trendVO);
		System.out.println(keywordList);
		return new ResponseEntity(keywordList, HttpStatus.OK);
	}
	
	// @GetMapping(value = "admin/viewKeyword")
	// public ModelAndView viewKeyword(@RequestParam String id, TrendVO trendVO)
	// {
	//
	// List<TrendVO> trendList = this.TrendService.getTrend();
	// List<KeywordVO> keywordList = new ArrayList<KeywordVO>();
	//
	// if (id != null) {
	// trendVO.setId(Integer.parseInt(id));
	// keywordList = this.KeywordService.getKeywordByTopic(trendVO);
	// System.out.println(keywordList.size());
	// } else if (trendList.size() > 0) {
	// trendVO = trendList.get(0);
	// keywordList = this.KeywordService.getKeywordByTopic(trendVO);
	// System.out.println(keywordList.size());
	// }
	//
	// return new ModelAndView("admin/viewKeyword", "keywordList",
	// keywordList).addObject("trendList", trendList);
	// }

	@GetMapping(value = "admin/deleteKeyword")
	public ModelAndView deleteKeyword(@RequestParam int id, KeywordVO keywordVO) {
		keywordVO.setId(id);

		List<KeywordVO> keywordList = this.KeywordService.getKeywordById(keywordVO);

		System.out.println(id);
		KeywordVO keywordVO2 = keywordList.get(0);
		keywordVO2.setStatus(false);
		System.out.println(keywordVO2);
		System.out.println(keywordVO2.isStatus());
		this.KeywordService.saveKeyword(keywordVO2);

		return new ModelAndView("redirect:viewKeyword");
	}

	@GetMapping(value = "admin/editKeyword")
	public ModelAndView editKeyword(@RequestParam int id, KeywordVO keywordVO) {
		keywordVO.setId(id);
		List<KeywordVO> keywordList = this.KeywordService.getKeywordById(keywordVO);
		List<TrendVO> trendList = this.TrendService.getTrend();

		return new ModelAndView("admin/editKeyword", "KeywordVO", keywordList.get(0)).addObject("trendList", trendList);
	}

	@PostMapping(value = "admin/updateKeyword")
	public ModelAndView updateKeyword(@ModelAttribute KeywordVO keywordVO) {

		keywordVO.setStatus(true);
		System.out.println("ads");
		this.KeywordService.updateKeyword(keywordVO);

		return new ModelAndView("redirect:viewKeyword");
	}

}
