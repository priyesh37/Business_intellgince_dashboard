package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.model.StopwordVO;
import com.project.service.StopwordService;
@Controller
public class StopwordController {

	@Autowired
	private StopwordService stopwordService;
	
	@GetMapping(value="admin/addStopword")
	public ModelAndView addStopword() {
		return new ModelAndView("admin/addStopword","StopwordVO",new StopwordVO());
	}

	@GetMapping(value="admin/viewStopword")
	public ModelAndView viewStopword() {
		List<StopwordVO> stopwordList= this.stopwordService.getStopword();
		return new ModelAndView("admin/viewStopword","stopwordList",stopwordList);
	}
	
	@PostMapping(value="admin/saveStopword")
	public ModelAndView saveStopword(@RequestParam String[] stopwords) {
		for (String string : stopwords) {
			StopwordVO stopwordVO = new StopwordVO();
			stopwordVO.setStatus(true);
			stopwordVO.setStopWord(string);
			this.stopwordService.saveStopword(stopwordVO);	
		}
		return new ModelAndView("redirect:viewStopword");
	}
	
	
	@GetMapping(value="admin/deleteStopword")
	public ModelAndView deleteStopword(@RequestParam int id,StopwordVO stopwordVO) {
		stopwordVO.setId(id);
		
		List<StopwordVO> stopwordList=this.stopwordService.getStopwordById(stopwordVO);
		StopwordVO stopwordVO2=stopwordList.get(0);
		stopwordVO2.setStatus(false);
		this.stopwordService.saveStopword(stopwordVO2);
		return new ModelAndView("redirect:viewStopword");
	}
	@GetMapping(value = "admin/editStopword")
	public ModelAndView editStopword(@RequestParam int id, StopwordVO stopwordVO) {
		stopwordVO.setId(id);
		List<StopwordVO> stopwordList = this.stopwordService.getStopwordById(stopwordVO);
	
		return new ModelAndView("admin/editStopword","StopwordVO", stopwordList.get(0));
	}
	@PostMapping(value = "admin/updateStopword")
	public ModelAndView updateStopword(@ModelAttribute StopwordVO stopwordVO) {

		stopwordVO.setStatus(true);
		System.out.println("ads");
			this.stopwordService.updateStopword(stopwordVO);
		
		return new ModelAndView("redirect:viewStopword");
	}
	
	
	
	
	
}
