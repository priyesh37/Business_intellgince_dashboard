package com.project.dao;
import java.util.List;

import com.project.model.TrendVO;

public interface TrendDAO {
	void saveTrend(TrendVO trendVO);
	List<TrendVO> getTrend();
	List<TrendVO> getTrendById(TrendVO TrendVO);

}
