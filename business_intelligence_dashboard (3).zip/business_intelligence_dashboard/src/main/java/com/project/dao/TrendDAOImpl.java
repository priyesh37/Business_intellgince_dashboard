package com.project.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.project.model.TrendVO;

@Repository
public class TrendDAOImpl implements TrendDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	

	@Override
	public void saveTrend(TrendVO trendVO) {
		//trendVO.setStatus(true);
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(trendVO);
		
		
	}



	@Override
	public List<TrendVO> getTrend() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("from TrendVO where status = true");
		List<TrendVO> trendList = query.list();
		return trendList;
	}



	@Override
	public List<TrendVO> getTrendById(TrendVO TrendVO) {
		
		Session session=this.sessionFactory.getCurrentSession();
		//System.out.println("from TrendVO where status=true and id="+TrendVO.getId());
		Query query=session.createQuery("from TrendVO where status=true and id="+TrendVO.getId());
		List<TrendVO> trendList = query.list();
		return trendList;
	}
	
	

}
