package com.project.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.model.CrawlPatternVO;
import com.project.model.FinalAbstractVO;
import com.project.model.KeywordCountVO;
import com.project.model.KeywordVO;
import com.project.model.PatternVO;
import com.project.model.TrendVO;

import javassist.compiler.ast.Keyword;

@Repository
public class CrawlDataDAOImpl implements CrawlDataDAO {
	@Autowired
	SessionFactory sessionFactory;


	@Override
	public List<TrendVO> getTrend(TrendVO trendVO) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		Query query=session.createQuery("select id from TrendVO where  status=true and trendName='"+trendVO.getTrendName()+"'");
		List trendList = query.list();
		return trendList;
	}


	@Override
	public void saveTrend(CrawlPatternVO crawlPatternVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(crawlPatternVO);
		
	}
	@Override
	public void savePattern(PatternVO patternVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(patternVO);
		
	}


	@Override
	public List<CrawlPatternVO> getCrawlPatternByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from CrawlPatternVO where trendVO.id=" + trendVO.getId());
		System.out.println(query);
		List<CrawlPatternVO> CrawlPattern = query.list();
		return CrawlPattern;
	}


	@Override
	public List<PatternVO> getPatternDetailsByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from PatternVO where trendVO.id=" + trendVO.getId());
		System.out.println(query);
		List<PatternVO> patternDetails = query.list();
		return patternDetails;
	}


	@Override
	public List<PatternVO> getPatternDetails(PatternVO patternVO) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		//System.out.println("from TrendVO where status=true and id="+TrendVO.getId());
		Query query=session.createQuery("from PatternVO where  id="+patternVO.getId());
		System.err.println(query);
		List<PatternVO> abstractList = query.list();
		return abstractList;
	}


	@Override
	public List<PatternVO> getAbstarctByTopic(TrendVO trendVO) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		//System.out.println("from TrendVO where status=true and id="+TrendVO.getId());
		Query query=session.createQuery(" from PatternVO  where  trend_id="+trendVO.getId());
		List<PatternVO> abstarctList = query.list();
		return abstarctList;
	}

	@Override
	public void saveFinalAbstract(FinalAbstractVO finalAbstractVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(finalAbstractVO);
		
	}


	@Override
	public List<FinalAbstractVO> getfinalabstract(TrendVO trendVO) {
		Session session=this.sessionFactory.getCurrentSession();
		//System.out.println("from TrendVO where status=true and id="+TrendVO.getId());
		Query query=session.createQuery(" from FinalAbstractVO  where  trend_id="+trendVO.getId());
		System.out.println(query);
		List<FinalAbstractVO> finalabstractList = query.list();
		System.out.println(finalabstractList.size());
		return finalabstractList;
	}


	@Override
	public void saveKeywordCount(KeywordCountVO keywordCountVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(keywordCountVO);
		
	}


	@Override
	public List getCount(TrendVO trendVO) {
		// TODO Auto-generated method stub
	int id=trendVO.getId();
		Session session=this.sessionFactory.getCurrentSession();
		Query query=session.createSQLQuery("SELECT SUM(countkeyword),keyword FROM keyword_count_table where trend_id='"+id+"' GROUP BY keyword");
	
		List countword=query.list();
		
		return countword;
		
	}


	@Override
	public List getCountFromYear(KeywordVO keywordVO) {
		String keyword=keywordVO.getKeyword();
	Session session=this.sessionFactory.getCurrentSession();
	Query query=session.createSQLQuery("SELECT keyword,YEAR,countkeyword FROM keyword_count_table WHERE keyword='"+keyword+"'");
	
	List countword=query.list();
	
	return countword;
	}
	
	

}
