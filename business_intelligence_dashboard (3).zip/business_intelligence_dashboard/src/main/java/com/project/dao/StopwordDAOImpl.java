package com.project.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.model.StopwordVO;
import com.project.model.TrendVO;

@Repository
public class StopwordDAOImpl implements StopwordDAO {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void saveStopword(StopwordVO stopwordVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(stopwordVO);

	}

	@Override
	public List<StopwordVO> getStopword() {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from StopwordVO where status=true");
		List<StopwordVO> stopwordList = query.list();
		return stopwordList;
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<StopwordVO> getStopwordById(StopwordVO stopwordVO) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from StopwordVO where status=true and id="+stopwordVO.getId());
		List<StopwordVO> stopwordList = query.list();
		return stopwordList;
	}
	
	@Override
	public void updateStopword(StopwordVO stopwordVO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(stopwordVO);

	}

}
