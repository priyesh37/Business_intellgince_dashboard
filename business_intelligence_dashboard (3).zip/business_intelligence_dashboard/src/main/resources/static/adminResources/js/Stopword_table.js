	

		var f2;
		var i=1;
		function Add()
		{
			if ($('#stopword1').val().trim() === '') {
				$('#stopword1').focus()
				showErrorToast('Please Enter Stop Word.')
				return false;
			}
			else{
			var stopword = document.getElementById("stopword1");
			if (stopword.value!= "") 
			{
			var div=document.getElementById("div");
			div.style.display="";
			var submit = document.getElementById("submit");
			submit.style.display = "";
			
			
				var table = document.getElementById("table");
				var row = table.insertRow(-1);
				var column1 = row.insertCell(0);
				column1.innerHTML = i;
				var column2 = row.insertCell(1);
				column2.innerHTML = "<input type='text'  style='border:0px' name='stopwords'  value='"+stopword.value+"'>";
				var column3 = row.insertCell(2);
				column3.innerHTML ='<button type="button" class="btn btn-danger btn-sm icon-btn ml-2" onclick="delete_row(this)"><i class="mdi mdi-delete"></i></button>';
				
			}
			stopword.value="";
			i++;
			}
		}
		function delete_row(s) {
			var table = document.getElementById("table");
			var f = s.parentNode.parentNode;
			table.deleteRow(f.rowIndex);

		}
			
			
		
			