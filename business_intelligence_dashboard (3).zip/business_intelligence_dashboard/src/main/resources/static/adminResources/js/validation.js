/*	
function validation()
{
	var d = document.getElementById("exampleInputEmail1");
	var d1 = document.getElementById("sem1");
	var d2 = document.getElementById("sem2");	
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
	if(d.value=="")
	{
		d.style.border="1px solid red";
        d1.style.display="";
		return false;
	}
	else if(!filter.test(d.value))
	{
		d.style.border="1px solid red";
		d1.style.display="none";
        d2.style.display="";
		return false;
    }
	
    else
	{
		d.style="display none";
		d1.style.display="none";
		d2.style.display="none";
    }
}*/
function validation() {
        var email = document.getElementById("exampleInputEmail1").value;
        var lblError = document.getElementById("sem1");
        lblError.innerHTML = "";
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (!expr.test(email)) {
            lblError.innerHTML = "Invalid email address.";
        }
    }
function CheckPasswordStrength(password) {
        var password_strength = document.getElementById("password_strength");
 
        //TextBox left blank.
        if (password.length == 0) {
            password_strength.innerHTML = "";
            return;
        }
 
        //Regular Expressions.
        var regex = new Array();
        regex.push("[A-Z]"); //Uppercase Alphabet.
        regex.push("[a-z]"); //Lowercase Alphabet.
        regex.push("[0-9]"); //Digit.
        regex.push("[$@$!%*#?&]"); //Special Character.
 
        var passed = 0;
 
        //Validate for each Regular Expression.
        for (var i = 0; i < regex.length; i++) {
            if (new RegExp(regex[i]).test(password)) {
                passed++;
            }
        }
 
        //Validate for length of Password.
        if (passed > 2 && password.length > 8) {
            passed++;
        }
 
        //Display status.
        var color = "";
        var strength = "";
        switch (passed) {
            case 0:
            case 1:
                strength = "Weak";
                color = "red";
                break;
            case 2:
                strength = "Good";
                color = "darkorange";
                break;
            case 3:
            case 4:
                strength = "Strong";
                color = "green";
                break;
            case 5:
                strength = "Very Strong";
                color = "darkgreen";
                break;
        }
        password_strength.innerHTML = strength;
        password_strength.style.color = color;
    }

//add trend
function validateForm() {
	  var x = document.forms["myForm"]["trendName"].value;
	  if (x == "") {
	    alert("Name must be filled out");
	    return false;
	  }
	}

