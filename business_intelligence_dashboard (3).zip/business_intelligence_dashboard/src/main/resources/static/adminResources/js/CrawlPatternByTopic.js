	function CrawlPatternByTopic()
	{
		var CrawlPattern=document.getElementById("CrawlPattern_Topic");
		var Table=document.getElementById("order-listing");
		
		var htp=new XMLHttpRequest();
	    
	    htp.onreadystatechange=function(){
	       
	        if(htp.readyState==4){
	        	var jsn=JSON.parse(htp.responseText);
	        	var	txt = '';
	        	
	        	for(var i=0;i<jsn.length;i++){
	        		txt= txt + '<tr>' + 
						'<td>'+ (i+1) + '</td>' + 
						'<td><a href='+jsn[i].link +'  target="_blank">'+jsn[i].link +'</a></td>';
						
				}
	        	$('#table1').html('').html(txt);
			
	        }
	    }
	
	    htp.open("get","findUrlPatternById?id="+CrawlPattern.value,true);
	    htp.send();
		
	}